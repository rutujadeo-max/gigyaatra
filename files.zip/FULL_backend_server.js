// backend/server.js
const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const mongoose = require('mongoose');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Joi = require('joi');

dotenv.config();

// ============ DATABASE MODELS ============

// User Model
const userSchema = new mongoose.Schema({
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    lowercase: true,
  },
  password: {
    type: String,
    required: [true, 'Password is required'],
    minlength: 6,
    select: false,
  },
  firstName: {
    type: String,
    required: [true, 'First name is required'],
  },
  lastName: String,
  bio: { type: String, maxlength: 500 },
  avatar: {
    type: String,
    default: 'https://api.dicebear.com/7.x/avataaars/svg?seed=default',
  },
  skills: [String],
  interests: [String],
  completedQuiz: { type: Boolean, default: false },
  savedGigs: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Gig' }],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

userSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

userSchema.methods.getPublicProfile = function () {
  const user = this.toObject();
  delete user.password;
  return user;
};

const User = mongoose.model('User', userSchema);

// Quiz Model
const quizSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  answers: {
    q1_personality: String,
    q2_workStyle: String,
    q3_creativity: String,
    q4_technical: String,
    q5_communication: String,
    q6_timeCommitment: String,
    q7_fieldOfInterest: String,
    q8_workEnvironment: String,
    q9_learningStyle: String,
    q10_goals: String,
  },
  predictedInterests: [String],
  confidenceScore: { type: Number, min: 0, max: 100 },
  submittedAt: { type: Date, default: Date.now },
});

const Quiz = mongoose.model('Quiz', quizSchema);

// Gig Model
const gigSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  category: {
    type: String,
    enum: ['Design', 'Development', 'Writing', 'Marketing', 'Music', 'Video', 'Data', 'Other'],
    required: true,
  },
  skillsRequired: [String],
  payRange: {
    min: Number,
    max: Number,
    currency: { type: String, default: 'USD' },
  },
  difficulty: {
    type: String,
    enum: ['Beginner', 'Intermediate', 'Expert'],
    default: 'Intermediate',
  },
  duration: {
    type: String,
    enum: ['One-time', 'Short-term (1-3 months)', 'Long-term (3+ months)', 'Ongoing'],
  },
  postedBy: String,
  location: { type: String, default: 'Remote' },
  applicants: { type: Number, default: 0 },
  image: {
    type: String,
    default: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=400',
  },
  createdAt: { type: Date, default: Date.now },
});

const Gig = mongoose.model('Gig', gigSchema);

// SavedGig Model
const savedGigSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  gigId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Gig',
    required: true,
  },
  status: {
    type: String,
    enum: ['saved', 'applied'],
    default: 'saved',
  },
  appliedAt: Date,
  savedAt: { type: Date, default: Date.now },
});

savedGigSchema.index({ userId: 1, gigId: 1 }, { unique: true });
const SavedGig = mongoose.model('SavedGig', savedGigSchema);

// ============ MIDDLEWARE ============

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
});

const authMiddleware = (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'No token provided' });

    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your_super_secret_key');
    req.userId = decoded.userId;
    req.email = decoded.email;
    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Token expired' });
    }
    return res.status(401).json({ error: 'Invalid token' });
  }
};

const validate = (schemaName) => {
  const schemas = {
    signup: Joi.object({
      email: Joi.string().email().required(),
      password: Joi.string().min(6).required(),
      firstName: Joi.string().required(),
      lastName: Joi.string().allow(''),
    }),
    login: Joi.object({
      email: Joi.string().email().required(),
      password: Joi.string().required(),
    }),
    quiz: Joi.object({
      q1_personality: Joi.string().required(),
      q2_workStyle: Joi.string().required(),
      q3_creativity: Joi.string().required(),
      q4_technical: Joi.string().required(),
      q5_communication: Joi.string().required(),
      q6_timeCommitment: Joi.string().required(),
      q7_fieldOfInterest: Joi.string().required(),
      q8_workEnvironment: Joi.string().required(),
      q9_learningStyle: Joi.string().required(),
      q10_goals: Joi.string().required(),
    }),
  };

  return (req, res, next) => {
    const schema = schemas[schemaName];
    if (!schema) return res.status(500).json({ error: 'Validation schema not found' });

    const { error, value } = schema.validate(req.body, { abortEarly: false });
    if (error) {
      const errors = error.details.map((detail) => ({
        field: detail.path[0],
        message: detail.message,
      }));
      return res.status(400).json({ errors });
    }

    req.validatedData = value;
    next();
  };
};

const errorHandler = (err, req, res, next) => {
  const status = err.status || err.statusCode || 500;
  const message = err.message || 'Internal server error';

  console.error('Error:', { status, message, path: req.path });

  if (err.name === 'ValidationError') {
    return res.status(400).json({
      error: 'Validation failed',
      details: Object.keys(err.errors).map((key) => ({
        field: key,
        message: err.errors[key].message,
      })),
    });
  }

  if (err.code === 11000) {
    const field = Object.keys(err.keyPattern)[0];
    return res.status(409).json({ error: `${field} already exists` });
  }

  res.status(status).json({ error: message });
};

// ============ RECOMMENDER ENGINE ============

const QUESTION_MAPPINGS = {
  q1_personality: {
    creative: { interest: 'Design', weight: 3 },
    analytical: { interest: 'Data', weight: 3 },
    social: { interest: 'Marketing', weight: 3 },
    practical: { interest: 'Development', weight: 2 },
  },
  q2_workStyle: {
    independent: { interest: 'Freelancing', weight: 2 },
    collaborative: { interest: 'Marketing', weight: 2 },
    structured: { interest: 'Development', weight: 2 },
    flexible: { interest: 'Writing', weight: 2 },
  },
  q3_creativity: {
    veryCreative: { interest: 'Design', weight: 3 },
    creative: { interest: 'Writing', weight: 2 },
    moderate: { interest: 'Marketing', weight: 2 },
    analytical: { interest: 'Data', weight: 2 },
  },
  q4_technical: {
    veryComfortable: { interest: 'Development', weight: 3 },
    comfortable: { interest: 'Data', weight: 2 },
    somewhat: { interest: 'Design', weight: 2 },
    notComfortable: { interest: 'Writing', weight: 3 },
  },
  q5_communication: {
    excellent: { interest: 'Marketing', weight: 2 },
    good: { interest: 'Writing', weight: 2 },
    moderate: { interest: 'Development', weight: 1 },
    prefer_listening: { interest: 'Design', weight: 1 },
  },
  q6_timeCommitment: {
    full_time: { interest: 'Development', weight: 2 },
    part_time: { interest: 'Writing', weight: 2 },
    flexible: { interest: 'Design', weight: 2 },
    occasional: { interest: 'Music', weight: 2 },
  },
  q7_fieldOfInterest: {
    technology: { interest: 'Development', weight: 3 },
    design: { interest: 'Design', weight: 3 },
    business: { interest: 'Marketing', weight: 3 },
    creative: { interest: 'Writing', weight: 3 },
    media: { interest: 'Video', weight: 3 },
    music: { interest: 'Music', weight: 3 },
  },
  q8_workEnvironment: {
    remote: { interest: 'Development', weight: 1 },
    office: { interest: 'Design', weight: 1 },
    hybrid: { interest: 'Marketing', weight: 1 },
    flexible: { interest: 'Writing', weight: 1 },
  },
  q9_learningStyle: {
    visual: { interest: 'Design', weight: 2 },
    hands_on: { interest: 'Development', weight: 2 },
    reading: { interest: 'Writing', weight: 2 },
    discussion: { interest: 'Marketing', weight: 2 },
  },
  q10_goals: {
    income: { interest: 'Development', weight: 2 },
    impact: { interest: 'Marketing', weight: 2 },
    expression: { interest: 'Design', weight: 2 },
    creation: { interest: 'Writing', weight: 2 },
    passion: { interest: 'Music', weight: 2 },
  },
};

const INTEREST_SKILLS = {
  Development: ['JavaScript', 'React', 'Node.js', 'Python', 'Full Stack', 'Vue.js', 'Git'],
  Design: ['UI/UX Design', 'Figma', 'Adobe XD', 'Photoshop', 'Web Design', 'Graphic Design'],
  Writing: ['Content Writing', 'Copywriting', 'Blog Writing', 'SEO Writing', 'Editing'],
  Marketing: ['Digital Marketing', 'Social Media', 'SEO', 'Analytics', 'Branding'],
  Data: ['Data Analysis', 'Python', 'SQL', 'Excel', 'Tableau', 'Statistics'],
  Video: ['Video Editing', 'Adobe Premiere', 'Filmmaking', 'Motion Graphics'],
  Music: ['Music Production', 'Sound Design', 'Mixing', 'Mastering'],
};

const INTEREST_GIG_CATEGORIES = {
  Development: ['Development'],
  Design: ['Design'],
  Writing: ['Writing'],
  Marketing: ['Marketing'],
  Data: ['Data'],
  Video: ['Video'],
  Music: ['Music'],
};

const predictInterests = (answers) => {
  const interestScores = {};

  Object.entries(answers).forEach(([question, answer]) => {
    const mapping = QUESTION_MAPPINGS[question];
    if (mapping && mapping[answer]) {
      const { interest, weight } = mapping[answer];
      interestScores[interest] = (interestScores[interest] || 0) + weight;
    }
  });

  const sortedInterests = Object.entries(interestScores)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  const totalScore = sortedInterests.reduce((sum, [, score]) => sum + score, 0);
  const maxScore = sortedInterests[0]?.[1] || 0;
  const confidenceScore = maxScore > 0 ? Math.round((maxScore / (totalScore / 2)) * 100) : 0;
  const interests = sortedInterests.map(([interest]) => interest);

  return { interests, confidenceScore };
};

const getSkillSuggestions = (interests) => {
  const skills = {};
  interests.forEach((interest) => {
    skills[interest] = INTEREST_SKILLS[interest] || [];
  });
  return skills;
};

const getGigCategories = (interests) => {
  const categories = new Set();
  interests.forEach((interest) => {
    const cats = INTEREST_GIG_CATEGORIES[interest];
    if (cats) cats.forEach((cat) => categories.add(cat));
  });
  return Array.from(categories);
};

// ============ INITIALIZE APP ============

const app = express();

app.use(limiter);
app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:3000', credentials: true }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));

// ============ CONNECT DATABASE ============

const connectDB = async () => {
  try {
    const mongoURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/gigyaatra';
    await mongoose.connect(mongoURI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('✓ MongoDB connected successfully');
  } catch (error) {
    console.error('✗ MongoDB connection error:', error.message);
    process.exit(1);
  }
};

connectDB();

// ============ SAMPLE GIGS DATA ============

const gigsData = [
  {
    title: 'Build E-commerce Platform for Fashion Startup',
    description: 'Need a full-stack developer to build a modern e-commerce platform with React, Node.js, and MongoDB.',
    category: 'Development',
    skillsRequired: ['React', 'Node.js', 'MongoDB', 'Stripe Integration'],
    payRange: { min: 5000, max: 15000 },
    difficulty: 'Expert',
    duration: 'Short-term (1-3 months)',
    postedBy: 'FashionFlow Startup',
    location: 'Remote',
    applicants: 24,
  },
  {
    title: 'UI/UX Design for SaaS Dashboard',
    description: 'Design complete UI/UX for project management SaaS. Include wireframes, prototypes, and design system.',
    category: 'Design',
    skillsRequired: ['Figma', 'UI Design', 'UX Research', 'Prototyping'],
    payRange: { min: 2000, max: 5000 },
    difficulty: 'Intermediate',
    duration: 'Short-term (1-3 months)',
    postedBy: 'ProjectFlow',
    location: 'Remote',
    applicants: 31,
  },
  {
    title: 'Blog Content Writing - Tech',
    description: 'Write 20 technical blog posts (1500-2000 words each). Topics: Web Development, DevOps, Cloud.',
    category: 'Writing',
    skillsRequired: ['Content Writing', 'Technical Writing', 'SEO', 'Research'],
    payRange: { min: 1200, max: 3000 },
    difficulty: 'Intermediate',
    duration: 'Short-term (1-3 months)',
    postedBy: 'TechBlog',
    location: 'Remote',
    applicants: 18,
  },
  {
    title: 'SEO Optimization Campaign',
    description: 'Optimize website for search engines. Keyword research, on-page SEO, backlink strategy.',
    category: 'Marketing',
    skillsRequired: ['SEO', 'Keyword Research', 'Technical SEO', 'Analytics'],
    payRange: { min: 1000, max: 3000 },
    difficulty: 'Intermediate',
    duration: 'Long-term (3+ months)',
    postedBy: 'SEOServices',
    location: 'Remote',
    applicants: 23,
  },
  {
    title: 'Data Analysis & Business Intelligence',
    description: 'Analyze sales data, create dashboards, identify trends. Tableau/Power BI expertise needed.',
    category: 'Data',
    skillsRequired: ['Data Analysis', 'Tableau', 'SQL', 'Statistics'],
    payRange: { min: 1500, max: 4000 },
    difficulty: 'Intermediate',
    duration: 'Short-term (1-3 months)',
    postedBy: 'DataCorp',
    location: 'Remote',
    applicants: 13,
  },
  {
    title: 'React Performance Optimization',
    description: 'Our React app is slow. Optimize components, implement code splitting, improve rendering.',
    category: 'Development',
    skillsRequired: ['React', 'Performance Optimization', 'JavaScript'],
    payRange: { min: 500, max: 2000 },
    difficulty: 'Intermediate',
    duration: 'One-time',
    postedBy: 'TechCorp Inc',
    location: 'Remote',
    applicants: 12,
  },
  {
    title: 'Brand Identity Design',
    description: 'Create complete brand identity for startup. Logo, color palette, typography, brand guidelines.',
    category: 'Design',
    skillsRequired: ['Adobe Creative Suite', 'Branding', 'Logo Design'],
    payRange: { min: 1500, max: 4000 },
    difficulty: 'Intermediate',
    duration: 'Short-term (1-3 months)',
    postedBy: 'StartupBrand Co',
    location: 'Remote',
    applicants: 26,
  },
  {
    title: 'Copywriting - Landing Pages',
    description: 'Write persuasive copy for 5 landing pages. High conversion focus. A/B testing included.',
    category: 'Writing',
    skillsRequired: ['Copywriting', 'Persuasive Writing', 'Marketing', 'Psychology'],
    payRange: { min: 1500, max: 3500 },
    difficulty: 'Intermediate',
    duration: 'One-time',
    postedBy: 'ConversionLabs',
    location: 'Remote',
    applicants: 22,
  },
  {
    title: 'Social Media Management',
    description: 'Manage social media accounts (Instagram, TikTok, LinkedIn). Content creation, community management.',
    category: 'Marketing',
    skillsRequired: ['Social Media Marketing', 'Content Creation', 'Engagement', 'Analytics'],
    payRange: { min: 800, max: 2000 },
    difficulty: 'Beginner',
    duration: 'Long-term (3+ months)',
    postedBy: 'BrandManager',
    location: 'Remote',
    applicants: 31,
  },
  {
    title: 'Next.js eCommerce Site Development',
    description: 'Create modern eCommerce storefront using Next.js. Product listings, cart, checkout, admin dashboard.',
    category: 'Development',
    skillsRequired: ['Next.js', 'React', 'Tailwind CSS', 'Stripe'],
    payRange: { min: 4000, max: 10000 },
    difficulty: 'Intermediate',
    duration: 'Short-term (1-3 months)',
    postedBy: 'RetailXpress',
    location: 'Remote',
    applicants: 22,
  },
];

// ============ API ROUTES ============

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Auth Routes
app.post('/api/auth/signup', validate('signup'), async (req, res, next) => {
  try {
    const { email, password, firstName, lastName } = req.validatedData;

    const existingUser = await User.findOne({ email });
    if (existingUser) return res.status(409).json({ error: 'Email already registered' });

    const user = new User({ email, password, firstName, lastName: lastName || '' });
    await user.save();

    const token = jwt.sign(
      { userId: user._id, email: user.email },
      process.env.JWT_SECRET || 'your_super_secret_key',
      { expiresIn: '7d' }
    );

    res.status(201).json({
      message: 'Account created successfully',
      token,
      user: user.getPublicProfile(),
    });
  } catch (error) {
    next(error);
  }
});

app.post('/api/auth/login', validate('login'), async (req, res, next) => {
  try {
    const { email, password } = req.validatedData;

    const user = await User.findOne({ email }).select('+password');
    if (!user || !(await user.matchPassword(password))) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const token = jwt.sign(
      { userId: user._id, email: user.email },
      process.env.JWT_SECRET || 'your_super_secret_key',
      { expiresIn: '7d' }
    );

    res.json({
      message: 'Login successful',
      token,
      user: user.getPublicProfile(),
    });
  } catch (error) {
    next(error);
  }
});

app.get('/api/auth/me', authMiddleware, async (req, res, next) => {
  try {
    const user = await User.findById(req.userId);
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json({ user: user.getPublicProfile() });
  } catch (error) {
    next(error);
  }
});

// Quiz Routes
app.post('/api/quiz/submit', authMiddleware, validate('quiz'), async (req, res, next) => {
  try {
    const userId = req.userId;
    const answers = req.validatedData;

    let quiz = await Quiz.findOne({ userId });
    const { interests, confidenceScore } = predictInterests(answers);

    if (quiz) {
      quiz.answers = answers;
      quiz.predictedInterests = interests;
      quiz.confidenceScore = confidenceScore;
      await quiz.save();
    } else {
      quiz = new Quiz({ userId, answers, predictedInterests: interests, confidenceScore });
      await quiz.save();
    }

    await User.findByIdAndUpdate(userId, {
      interests,
      completedQuiz: true,
    });

    res.json({
      message: 'Quiz submitted successfully',
      quiz: { interests, confidenceScore },
    });
  } catch (error) {
    next(error);
  }
});

app.get('/api/quiz/:userId', async (req, res, next) => {
  try {
    const quiz = await Quiz.findOne({ userId: req.params.userId });
    if (!quiz) return res.status(404).json({ error: 'Quiz not found' });
    res.json({ quiz });
  } catch (error) {
    next(error);
  }
});

// Gigs Routes
app.get('/api/gigs', async (req, res, next) => {
  try {
    const { category, difficulty, search, page = 1, limit = 12 } = req.query;
    const filter = {};

    if (category) filter.category = category;
    if (difficulty) filter.difficulty = difficulty;
    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
      ];
    }

    const skip = (page - 1) * limit;
    const gigs = await Gig.find(filter).skip(skip).limit(parseInt(limit)).sort({ createdAt: -1 });
    const total = await Gig.countDocuments(filter);

    res.json({
      gigs,
      pagination: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    next(error);
  }
});

app.get('/api/gigs/:id', async (req, res, next) => {
  try {
    const gig = await Gig.findById(req.params.id);
    if (!gig) return res.status(404).json({ error: 'Gig not found' });
    res.json({ gig });
  } catch (error) {
    next(error);
  }
});

app.post('/api/gigs/:id/save', authMiddleware, async (req, res, next) => {
  try {
    const userId = req.userId;
    const { id: gigId } = req.params;

    const gig = await Gig.findById(gigId);
    if (!gig) return res.status(404).json({ error: 'Gig not found' });

    let savedGig = await SavedGig.findOne({ userId, gigId });

    if (savedGig) {
      await SavedGig.deleteOne({ userId, gigId });
      await User.findByIdAndUpdate(userId, { $pull: { savedGigs: gigId } });
      return res.json({ message: 'Gig removed from saved' });
    } else {
      savedGig = new SavedGig({ userId, gigId });
      await savedGig.save();
      await User.findByIdAndUpdate(userId, { $addToSet: { savedGigs: gigId } });
      return res.json({ message: 'Gig saved successfully' });
    }
  } catch (error) {
    next(error);
  }
});

app.get('/api/gigs/saved/all', authMiddleware, async (req, res, next) => {
  try {
    const userId = req.userId;
    const savedGigs = await SavedGig.find({ userId }).populate('gigId').sort({ savedAt: -1 });
    const gigs = savedGigs.map((sg) => sg.gigId);

    res.json({ count: gigs.length, gigs });
  } catch (error) {
    next(error);
  }
});

// Recommendations Routes
app.get('/api/recommendations/interests', authMiddleware, async (req, res, next) => {
  try {
    const quiz = await Quiz.findOne({ userId: req.userId });

    if (!quiz) {
      return res.status(404).json({
        error: 'Complete quiz first',
        message: 'User has not completed the interest discovery quiz',
      });
    }

    res.json({
      interests: quiz.predictedInterests,
      confidenceScore: quiz.confidenceScore,
    });
  } catch (error) {
    next(error);
  }
});

app.get('/api/recommendations/skills', authMiddleware, async (req, res, next) => {
  try {
    const user = await User.findById(req.userId);

    if (!user.interests || user.interests.length === 0) {
      return res.status(400).json({
        error: 'Complete quiz first',
        message: 'User needs to complete quiz for skill recommendations',
      });
    }

    const recommendedSkills = getSkillSuggestions(user.interests);

    res.json({
      interests: user.interests,
      recommendedSkills,
      currentSkills: user.skills,
    });
  } catch (error) {
    next(error);
  }
});

app.get('/api/recommendations/gigs', authMiddleware, async (req, res, next) => {
  try {
    const user = await User.findById(req.userId);

    if (!user.interests || user.interests.length === 0) {
      return res.status(400).json({ error: 'Complete quiz first' });
    }

    const gigCategories = getGigCategories(user.interests);
    const gigs = await Gig.find({ category: { $in: gigCategories } }).limit(12).sort({ createdAt: -1 });

    res.json({
      recommendedFor: user.interests,
      categories: gigCategories,
      gigsCount: gigs.length,
      gigs,
    });
  } catch (error) {
    next(error);
  }
});

// Profile Routes
app.get('/api/profile', authMiddleware, async (req, res, next) => {
  try {
    const user = await User.findById(req.userId).populate('savedGigs', 'title category payRange');
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json({ user: user.getPublicProfile() });
  } catch (error) {
    next(error);
  }
});

app.put('/api/profile', authMiddleware, async (req, res, next) => {
  try {
    const { firstName, lastName, bio, skills } = req.body;

    const updatedUser = await User.findByIdAndUpdate(
      req.userId,
      {
        firstName: firstName || undefined,
        lastName: lastName || undefined,
        bio: bio || undefined,
        skills: skills || undefined,
        updatedAt: new Date(),
      },
      { new: true, runValidators: true }
    );

    res.json({
      message: 'Profile updated successfully',
      user: updatedUser.getPublicProfile(),
    });
  } catch (error) {
    next(error);
  }
});

app.post('/api/profile/skills', authMiddleware, async (req, res, next) => {
  try {
    const { skill } = req.body;
    if (!skill) return res.status(400).json({ error: 'Skill is required' });

    const user = await User.findByIdAndUpdate(
      req.userId,
      { $addToSet: { skills: skill } },
      { new: true }
    );

    res.json({ message: 'Skill added!', skills: user.skills });
  } catch (error) {
    next(error);
  }
});

app.delete('/api/profile/skills', authMiddleware, async (req, res, next) => {
  try {
    const { skill } = req.body;
    if (!skill) return res.status(400).json({ error: 'Skill is required' });

    const user = await User.findByIdAndUpdate(
      req.userId,
      { $pull: { skills: skill } },
      { new: true }
    );

    res.json({ message: 'Skill removed!', skills: user.skills });
  } catch (error) {
    next(error);
  }
});

// 404 Handler
app.use((req, res) => {
  res.status(404).json({
    error: 'Endpoint not found',
    path: req.path,
    method: req.method,
  });
});

// Error handling
app.use(errorHandler);

// ============ SEED DATABASE ============

const seedDatabase = async () => {
  try {
    const userCount = await User.countDocuments();
    const gigCount = await Gig.countDocuments();

    if (userCount === 0) {
      const demoUser = new User({
        email: 'demo@gigyaatra.com',
        password: 'Demo@123',
        firstName: 'Demo',
        lastName: 'User',
        bio: 'Freelancer looking for exciting opportunities',
        interests: ['Design', 'Development'],
        skills: ['JavaScript', 'React', 'UI Design'],
      });
      await demoUser.save();
      console.log('✓ Demo user created: demo@gigyaatra.com / Demo@123');
    }

    if (gigCount === 0) {
      await Gig.insertMany(gigsData);
      console.log(`✓ ${gigsData.length} gigs inserted`);
    }
  } catch (error) {
    console.error('Error seeding database:', error);
  }
};

seedDatabase();

// ============ START SERVER ============

const PORT = process.env.PORT || 5000;
const server = app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════╗
║     🚀 GigYaatra Server Started    ║
╠════════════════════════════════════╣
║ Environment: ${(process.env.NODE_ENV || 'development').padEnd(22)} ║
║ Port: ${String(PORT).padEnd(28)} ║
║ API: http://localhost:${PORT}    ║
╚════════════════════════════════════╝
  `);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  server.close(() => {
    console.log('Server closed');
    mongoose.connection.close(false, () => {
      console.log('MongoDB connection closed');
      process.exit(0);
    });
  });
});
