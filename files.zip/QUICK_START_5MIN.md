# ⚡ GIGYAATRA - 5 MINUTE QUICK START

## 📥 DOWNLOAD ALL 11 FILES FROM ABOVE

---

## 🎯 DO THIS (10 STEPS)

### STEP 1: Create Folders
```bash
mkdir GigYaatra && cd GigYaatra
mkdir backend frontend frontend/src frontend/public
```

### STEP 2: Backend Setup
```bash
cd backend
```

Save these 3 files in `backend/` folder:
- `FULL_backend_server.js` → Save as `server.js`
- `FULL_backend_package.json` → Save as `package.json`  
- `FULL_backend_env` → Save as `.env`

### STEP 3: Edit .env (Backend)
Open `backend/.env` and make sure it has:
```
PORT=5000
NODE_ENV=development
CLIENT_URL=http://localhost:3000
MONGODB_URI=mongodb://localhost:27017/gigyaatra
JWT_SECRET=your_super_secret_key_min_32_chars_long
```

### STEP 4: Install Backend
```bash
npm install
```
Wait for it to finish...

### STEP 5: Frontend Setup
```bash
cd ../frontend
```

Save these 6 files in `frontend/`:
- `FULL_frontend_package.json` → Save as `package.json`
- `FULL_frontend_env` → Save as `.env`

Save these 4 files in `frontend/src/`:
- `FULL_frontend_App.jsx` → Save as `App.jsx`
- `FULL_frontend_App.css` → Save as `App.css`
- `FULL_frontend_index.js` → Save as `index.js`

Save this file in `frontend/public/`:
- `FULL_frontend_index.html` → Save as `index.html`

### STEP 6: Install Frontend
```bash
npm install
```
Wait for it to finish...

### STEP 7: Start Backend
Open Terminal 1:
```bash
cd backend
npm run dev
```

You'll see:
```
🚀 GigYaatra Server Started
Port: 5000
```

### STEP 8: Start Frontend
Open Terminal 2:
```bash
cd frontend
npm start
```

Browser opens to `http://localhost:3000`

### STEP 9: Login
Use demo account:
- Email: `demo@gigyaatra.com`
- Password: `Demo@123`

### STEP 10: Test Everything ✅
- ✅ Quiz works
- ✅ Dashboard shows recommendations
- ✅ Can browse gigs
- ✅ Can save gigs
- ✅ Can edit profile
- ✅ Can add skills

---

## ❌ ISSUES?

### Port already in use?
```bash
# Mac/Linux:
lsof -ti:3000 | xargs kill -9
lsof -ti:5000 | xargs kill -9

# Windows:
netstat -ano | findstr :3000
taskkill /PID <PID> /F
```

### npm install fails?
```bash
rm -rf node_modules package-lock.json
npm install
```

### MongoDB error?
Either:
- Start MongoDB locally: `mongod`
- OR use MongoDB Atlas cloud (free at mongodb.com)

### Files in wrong place?
Check this structure:
```
GigYaatra/
├── backend/
│   ├── server.js
│   ├── package.json
│   └── .env
└── frontend/
    ├── src/ (App.jsx, App.css, index.js)
    ├── public/ (index.html)
    ├── package.json
    └── .env
```

---

## 📖 FULL GUIDE

Read `VSCODE_SETUP_GUIDE.md` for detailed explanations

---

## 🚀 YOU'RE DONE!

Visit: **http://localhost:3000**

Enjoy! 🎉
