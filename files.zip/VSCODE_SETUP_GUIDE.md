# 🚀 GIGYAATRA - COMPLETE VS CODE SETUP GUIDE

## ⚡ YOU HAVE ALL THE CODE - FOLLOW THESE STEPS EXACTLY

---

## STEP 1: CREATE PROJECT STRUCTURE

Open Terminal and run these commands:

```bash
# Create main project folder
mkdir GigYaatra
cd GigYaatra

# Create backend folder structure
mkdir backend

# Create frontend folder structure
mkdir frontend
mkdir frontend/src
mkdir frontend/public
```

---

## STEP 2: SETUP BACKEND

### 2.1 Navigate to backend folder
```bash
cd backend
```

### 2.2 Create files in backend folder

**File 1: package.json**
- Copy content from: FULL_backend_package.json
- Save as: `backend/package.json`

**File 2: server.js**
- Copy content from: FULL_backend_server.js
- Save as: `backend/server.js`

**File 3: .env**
- Copy content from: FULL_backend_env
- Save as: `backend/.env`
- **IMPORTANT**: Edit these settings in .env:
  ```
  PORT=5000
  NODE_ENV=development
  CLIENT_URL=http://localhost:3000
  MONGODB_URI=mongodb://localhost:27017/gigyaatra
  JWT_SECRET=your_super_secret_key_min_32_chars_long
  ```

### 2.3 Install backend dependencies
```bash
npm install
```

**Wait for installation to complete** - This will take 2-3 minutes

---

## STEP 3: SETUP FRONTEND

### 3.1 Go back to main folder and navigate to frontend
```bash
cd ..
cd frontend
```

### 3.2 Create files in frontend folder

**File 1: package.json**
- Copy content from: FULL_frontend_package.json
- Save as: `frontend/package.json`

**File 2: .env**
- Copy content from: FULL_frontend_env
- Save as: `frontend/.env`
- Leave as is (default is correct)

### 3.3 Create src folder files

```bash
mkdir -p src
```

**File 1: src/App.jsx**
- Copy content from: FULL_frontend_App.jsx
- Save as: `frontend/src/App.jsx`

**File 2: src/App.css**
- Copy content from: FULL_frontend_App.css
- Save as: `frontend/src/App.css`

**File 3: src/index.js**
- Copy content from: FULL_frontend_index.js
- Save as: `frontend/src/index.js`

### 3.4 Create public folder files

```bash
mkdir -p public
```

**File 1: public/index.html**
- Copy content from: FULL_frontend_index.html
- Save as: `frontend/public/index.html`

### 3.5 Install frontend dependencies
```bash
npm install
```

**Wait for installation to complete** - This will take 3-4 minutes

---

## STEP 4: START THE APPLICATION

### IMPORTANT: You need TWO terminal windows (one for backend, one for frontend)

### Terminal 1: Start Backend
```bash
# From GigYaatra/backend
cd backend
npm run dev
```

You should see:
```
╔════════════════════════════════════╗
║     🚀 GigYaatra Server Started    ║
╠════════════════════════════════════╣
║ Environment: development           ║
║ Port: 5000                         ║
║ API: http://localhost:5000         ║
╚════════════════════════════════════╝
```

✅ Keep this terminal open

### Terminal 2: Start Frontend
Open a NEW terminal window and run:
```bash
# From GigYaatra/frontend
cd frontend
npm start
```

You should see:
```
✓ Compiled successfully!
✓ Opened http://localhost:3000
```

✅ Browser should open automatically at http://localhost:3000

---

## STEP 5: TEST THE APPLICATION

### Visit http://localhost:3000 in your browser

### Click "Get Started Free" or "Sign In"

### Use Demo Credentials:
- **Email**: demo@gigyaatra.com
- **Password**: Demo@123

### You should see:
1. ✅ Login successful
2. ✅ Redirected to Quiz page
3. ✅ Can answer 10 quiz questions
4. ✅ Redirected to Dashboard with recommendations
5. ✅ Can browse gigs
6. ✅ Can save gigs to profile
7. ✅ Can edit profile and add skills

---

## 🎯 FOLDER STRUCTURE (FINAL)

```
GigYaatra/
│
├── backend/
│   ├── server.js          ← Paste FULL_backend_server.js
│   ├── package.json       ← Paste FULL_backend_package.json
│   └── .env               ← Paste FULL_backend_env (then edit)
│
├── frontend/
│   ├── public/
│   │   └── index.html     ← Paste FULL_frontend_index.html
│   ├── src/
│   │   ├── App.jsx        ← Paste FULL_frontend_App.jsx
│   │   ├── App.css        ← Paste FULL_frontend_App.css
│   │   └── index.js       ← Paste FULL_frontend_index.js
│   ├── package.json       ← Paste FULL_frontend_package.json
│   └── .env               ← Paste FULL_frontend_env
│
└── (optional) Downloaded files folder
```

---

## 🔧 TROUBLESHOOTING

### "npm: command not found"
- **Solution**: Install Node.js from https://nodejs.org (LTS version)
- Restart terminal after installation

### "Cannot find module" error
```bash
# Go to the folder where error occurred
cd backend   # or cd frontend
rm -rf node_modules package-lock.json
npm install
```

### Port 3000 already in use
```bash
# Kill process on port 3000
# On Mac/Linux:
lsof -ti:3000 | xargs kill -9

# On Windows:
netstat -ano | findstr :3000
taskkill /PID <PID> /F
```

### Port 5000 already in use
```bash
# Kill process on port 5000
# On Mac/Linux:
lsof -ti:5000 | xargs kill -9

# On Windows:
netstat -ano | findstr :5000
taskkill /PID <PID> /F
```

### MongoDB connection error
**You need MongoDB running locally OR use MongoDB Atlas (cloud)**

#### Option A: Local MongoDB
```bash
# Start MongoDB server
mongod
```

#### Option B: MongoDB Atlas (Cloud - Easier)
1. Go to https://www.mongodb.com/cloud/atlas
2. Create free account
3. Create cluster
4. Get connection string
5. Edit `backend/.env`:
   ```
   MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/gigyaatra?retryWrites=true&w=majority
   ```

### Blank page in browser
1. Press F12 to open developer console
2. Check for error messages
3. Verify backend is running: http://localhost:5000/api/health
4. Check frontend .env has correct API_URL
5. Clear browser cache: Ctrl+Shift+Delete (Windows) or Cmd+Shift+Delete (Mac)

### "Cannot GET /api/gigs"
- ✅ Make sure backend is running (`npm run dev` in terminal 1)
- ✅ Check terminal 1 shows "🚀 GigYaatra Server Started"
- ✅ Verify .env files have correct values

---

## 📊 FILE CHECKLIST

Use this to verify you have all files:

### Backend Files ✅
- [ ] backend/server.js
- [ ] backend/package.json
- [ ] backend/.env

### Frontend Files ✅
- [ ] frontend/public/index.html
- [ ] frontend/src/App.jsx
- [ ] frontend/src/App.css
- [ ] frontend/src/index.js
- [ ] frontend/package.json
- [ ] frontend/.env

---

## 🎓 WHAT TO DO AFTER SETUP

### 1. Explore the Code
- Open `frontend/src/App.jsx` - This is the ENTIRE frontend
- Read through it to understand the structure
- All components are in one file for simplicity

### 2. Test All Features
- ✅ Signup with new email
- ✅ Complete the 10-step quiz
- ✅ View recommendations on dashboard
- ✅ Browse 10+ gigs
- ✅ Save gigs
- ✅ Edit profile
- ✅ Add skills

### 3. Customize
- Change colors in App.jsx (find "bg-cyan-500" and replace with your color)
- Add more gigs in `backend/server.js` (find `const gigsData = [` section)
- Modify quiz questions in `frontend/src/App.jsx` (find `const quizQuestions = [`)

### 4. Deploy (Later)
- Backend: Deploy to Render.com
- Frontend: Deploy to Vercel

---

## 💡 USEFUL VS CODE EXTENSIONS

Install these for better development experience:

1. **ES7+ React/Redux/React-Native snippets**
   - Provides code shortcuts for React

2. **Thunder Client** or **REST Client**
   - Test API endpoints directly in VS Code

3. **Tailwind CSS IntelliSense**
   - Autocomplete for Tailwind classes

4. **MongoDB for VS Code**
   - Browse your database from VS Code

---

## ✨ QUICK REFERENCE

### Start the app (every time)
```bash
# Terminal 1 - Backend
cd backend && npm run dev

# Terminal 2 - Frontend
cd frontend && npm start
```

### Visit in browser
```
http://localhost:3000
```

### Demo login
```
Email: demo@gigyaatra.com
Password: Demo@123
```

### Stop the app
```
Ctrl+C in each terminal
```

---

## 🎉 YOU'RE ALL SET!

Everything is complete and ready to run. The application includes:

✅ **Complete Backend**
- User authentication (signup/login)
- 10-step interest discovery quiz
- AI recommendation engine
- 10+ gigs with filtering
- User profile management
- All API endpoints working

✅ **Complete Frontend**
- 6 full pages (Landing, Auth, Quiz, Dashboard, Profile, Gigs)
- All components integrated
- Responsive design
- Working features

✅ **Ready to Go**
- No additional code needed
- Just copy & paste files
- Follow these steps
- It will work!

---

## 📞 IF SOMETHING DOESN'T WORK

1. **Check terminal for error messages** - Copy the exact error
2. **Verify all files are in correct folders** - Use folder structure above
3. **Make sure both terminals are running** - Backend AND Frontend
4. **Clear cache** - Ctrl+Shift+Delete in browser
5. **Restart everything** - Kill terminals, npm install again, restart

---

**🚀 START NOW - You have everything you need!**

**Questions?** Check the error messages in terminal - they usually tell you exactly what's wrong.

**Good luck! 🎉**
