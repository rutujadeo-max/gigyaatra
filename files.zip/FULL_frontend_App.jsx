// frontend/src/App.jsx - COMPLETE FRONTEND APPLICATION
import React, { useEffect, useState, useContext, createContext } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
import './App.css';

// ============ CONFIGURATION ============
const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

// ============ API SERVICE ============
const apiClient = axios.create({
  baseURL: API_URL,
  headers: { 'Content-Type': 'application/json' },
});

apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

const api = {
  signup: (data) => apiClient.post('/auth/signup', data),
  login: (data) => apiClient.post('/auth/login', data),
  getCurrentUser: (token) =>
    axios.get(`${API_URL}/auth/me`, {
      headers: { Authorization: `Bearer ${token}` },
    }),
  submitQuiz: (answers) => apiClient.post('/quiz/submit', answers),
  getQuiz: (userId) => apiClient.get(`/quiz/${userId}`),
  getAllGigs: (params) => apiClient.get('/gigs', { params }),
  getGigById: (id) => apiClient.get(`/gigs/${id}`),
  saveGig: (id) => apiClient.post(`/gigs/${id}/save`),
  getSavedGigs: () => apiClient.get('/gigs/saved/all'),
  getInterestRecommendations: () => apiClient.get('/recommendations/interests'),
  getSkillRecommendations: () => apiClient.get('/recommendations/skills'),
  getGigRecommendations: () => apiClient.get('/recommendations/gigs'),
  getProfile: () => apiClient.get('/profile'),
  updateProfile: (data) => apiClient.put('/profile', data),
  addSkill: (skill) => apiClient.post('/profile/skills', { skill }),
  removeSkill: (skill) => apiClient.delete('/profile/skills', { data: { skill } }),
};

// ============ CONTEXT ============
const AuthContext = createContext();
const UserContext = createContext();

const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (token) verifyToken();
  }, []);

  const verifyToken = async () => {
    try {
      const response = await api.getCurrentUser(token);
      setUser(response.data.user);
    } catch (err) {
      localStorage.removeItem('token');
      setToken(null);
    }
  };

  const signup = async (email, password, firstName, lastName) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await api.signup({ email, password, firstName, lastName });
      const { token: newToken, user: userData } = response.data;
      localStorage.setItem('token', newToken);
      setToken(newToken);
      setUser(userData);
      return response.data;
    } catch (err) {
      const errorMessage = err.response?.data?.error || 'Signup failed';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const login = async (email, password) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await api.login({ email, password });
      const { token: newToken, user: userData } = response.data;
      localStorage.setItem('token', newToken);
      setToken(newToken);
      setUser(userData);
      return response.data;
    } catch (err) {
      const errorMessage = err.response?.data?.error || 'Login failed';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    setToken(null);
    setUser(null);
    setError(null);
  };

  const value = {
    user,
    token,
    isLoading,
    error,
    signup,
    login,
    logout,
    isAuthenticated: !!token,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

const UserProvider = ({ children }) => {
  const [userProfile, setUserProfile] = useState(null);
  const [interests, setInterests] = useState([]);
  const [skills, setSkills] = useState([]);
  const [recommendations, setRecommendations] = useState(null);
  const [savedGigs, setSavedGigs] = useState([]);

  const updateProfile = (profile) => {
    setUserProfile(profile);
    setInterests(profile.interests || []);
    setSkills(profile.skills || []);
  };

  const toggleSavedGig = (gigId) => {
    setSavedGigs((prev) =>
      prev.includes(gigId) ? prev.filter((id) => id !== gigId) : [...prev, gigId]
    );
  };

  const value = {
    userProfile,
    setUserProfile,
    interests,
    setInterests,
    skills,
    setSkills,
    recommendations,
    setRecommendations,
    savedGigs,
    setSavedGigs,
    toggleSavedGig,
    updateProfile,
  };

  return <UserContext.Provider value={value}>{children}</UserContext.Provider>;
};

// ============ COMPONENTS ============

const LoadingSpinner = () => (
  <div className="flex items-center justify-center min-h-screen">
    <div className="text-center">
      <div className="w-12 h-12 border-4 border-slate-700 border-t-cyan-500 rounded-full animate-spin mx-auto mb-4"></div>
      <p className="text-slate-300">Loading...</p>
    </div>
  </div>
);

const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, isLoading } = useContext(AuthContext);
  if (isLoading) return <LoadingSpinner />;
  if (!isAuthenticated) return <Navigate to="/auth" replace />;
  return children;
};

const Navbar = () => {
  const { isAuthenticated, user, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  return (
    <nav className="bg-slate-950 border-b border-slate-700 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <button
            onClick={() => navigate('/')}
            className="flex items-center space-x-2 group hover:opacity-80 transition"
          >
            <div className="w-8 h-8 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">GY</span>
            </div>
            <span className="hidden sm:inline font-bold text-white">GigYaatra</span>
          </button>

          <div className="flex items-center space-x-6">
            {isAuthenticated ? (
              <>
                <button
                  onClick={() => navigate('/dashboard')}
                  className="text-slate-300 hover:text-white transition text-sm"
                >
                  Dashboard
                </button>
                <button
                  onClick={() => navigate('/gigs')}
                  className="text-slate-300 hover:text-white transition text-sm"
                >
                  Gigs
                </button>
                <button
                  onClick={() => navigate('/profile')}
                  className="text-slate-300 hover:text-white transition text-sm"
                >
                  Profile
                </button>

                <div className="flex items-center space-x-3 pl-6 border-l border-slate-700">
                  <img
                    src={user?.avatar || 'https://api.dicebear.com/7.x/avataaars/svg?seed=default'}
                    alt="Avatar"
                    className="w-8 h-8 rounded-full"
                  />
                  <button
                    onClick={() => {
                      logout();
                      navigate('/');
                    }}
                    className="ml-2 px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded text-sm transition"
                  >
                    Logout
                  </button>
                </div>
              </>
            ) : (
              <>
                <button
                  onClick={() => navigate('/auth')}
                  className="text-slate-300 hover:text-white transition text-sm"
                >
                  Sign In
                </button>
                <button
                  onClick={() => navigate('/auth')}
                  className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-lg hover:shadow-lg transition text-sm font-medium"
                >
                  Get Started
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

const GigCard = ({ gig, isSaved = false, onSaveToggle }) => {
  const { token } = useContext(AuthContext);
  const [loading, setLoading] = useState(false);

  const handleSave = async () => {
    if (!token) return;
    setLoading(true);
    try {
      await api.saveGig(gig._id);
      if (onSaveToggle) onSaveToggle(gig._id);
    } catch (error) {
      console.error('Error saving gig:', error);
    } finally {
      setLoading(false);
    }
  };

  const getDifficultyColor = (difficulty) => {
    const colors = {
      Beginner: 'bg-green-100 text-green-800',
      Intermediate: 'bg-yellow-100 text-yellow-800',
      Expert: 'bg-red-100 text-red-800',
    };
    return colors[difficulty] || 'bg-gray-100 text-gray-800';
  };

  const getCategoryColor = (category) => {
    const colors = {
      Development: 'bg-blue-50 border-blue-200',
      Design: 'bg-purple-50 border-purple-200',
      Writing: 'bg-green-50 border-green-200',
      Marketing: 'bg-orange-50 border-orange-200',
      Data: 'bg-pink-50 border-pink-200',
      Video: 'bg-red-50 border-red-200',
      Music: 'bg-indigo-50 border-indigo-200',
    };
    return colors[category] || 'bg-gray-50 border-gray-200';
  };

  return (
    <div className={`rounded-lg border-2 p-5 hover:shadow-lg transition ${getCategoryColor(gig.category)}`}>
      <div className="flex justify-between items-start mb-3">
        <div className="flex-1">
          <h3 className="font-bold text-lg text-gray-900 mb-1">{gig.title}</h3>
          <p className="text-sm text-gray-600">{gig.postedBy}</p>
        </div>
        <button
          onClick={handleSave}
          disabled={loading}
          className={`ml-2 p-2 rounded transition ${
            isSaved
              ? 'text-red-500 bg-red-50'
              : 'text-gray-400 hover:text-cyan-500 hover:bg-cyan-50'
          }`}
        >
          {loading ? '⏳' : isSaved ? '❤️' : '🤍'}
        </button>
      </div>

      <p className="text-sm text-gray-700 mb-4 line-clamp-2">{gig.description}</p>

      <div className="flex flex-wrap gap-2 mb-4">
        <span className={`px-3 py-1 rounded-full text-xs font-medium ${getDifficultyColor(gig.difficulty)}`}>
          {gig.difficulty}
        </span>
        <span className="px-3 py-1 bg-slate-200 text-slate-800 rounded-full text-xs font-medium">
          {gig.category}
        </span>
      </div>

      <div className="flex justify-between items-center">
        <div>
          <p className="text-lg font-bold text-gray-900">
            ${gig.payRange?.min?.toLocaleString() || 0}-${gig.payRange?.max?.toLocaleString() || 0}
          </p>
          <p className="text-xs text-gray-600">{gig.duration}</p>
        </div>
        <button className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-lg hover:shadow-lg transition text-sm font-medium">
          View Details
        </button>
      </div>
    </div>
  );
};

const SkillCard = ({ interest, skills }) => (
  <div className="bg-white rounded-lg p-6 border-2 border-slate-200 hover:border-cyan-400 transition">
    <h3 className="font-bold text-lg text-gray-900 mb-4">
      <span className="w-3 h-3 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full mr-2 inline-block"></span>
      {interest}
    </h3>
    <div className="flex flex-wrap gap-2">
      {skills?.slice(0, 5).map((skill, i) => (
        <span
          key={i}
          className="px-3 py-1 bg-gradient-to-r from-cyan-50 to-blue-50 border border-cyan-200 rounded-full text-sm text-cyan-700 font-medium"
        >
          {skill}
        </span>
      ))}
    </div>
  </div>
);

// ============ PAGES ============

const Landing = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6 leading-tight">
            Discover Your Path.<br />
            <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              Master Your Skills.
            </span><br />
            Land Amazing Gigs.
          </h1>
          <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto">
            Take our AI-powered quiz to discover your talents, get personalized skill recommendations, and find gigs
            that match your interests.
          </p>
          <div className="flex gap-4 justify-center">
            <button
              onClick={() => navigate('/auth')}
              className="px-8 py-4 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition font-bold text-lg"
            >
              Get Started Free
            </button>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mt-20">
          {[
            { icon: '🎯', title: 'Interest Discovery', desc: 'Take our interactive quiz to uncover your true interests.' },
            { icon: '🤖', title: 'AI Recommendations', desc: 'Get personalized skill suggestions based on your profile.' },
            { icon: '💼', title: 'Gig Opportunities', desc: 'Discover 50+ freelance opportunities tailored to your skills.' },
          ].map((feature, i) => (
            <div
              key={i}
              className="bg-slate-800 rounded-lg p-8 border border-slate-700 hover:border-cyan-500 transition"
            >
              <div className="text-4xl mb-4">{feature.icon}</div>
              <h3 className="text-xl font-bold text-white mb-3">{feature.title}</h3>
              <p className="text-slate-300">{feature.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const Auth = () => {
  const [isSignup, setIsSignup] = useState(false);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login, signup } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (isSignup) {
        await signup(formData.email, formData.password, formData.firstName, formData.lastName);
      } else {
        await login(formData.email, formData.password);
      }
      navigate('/quiz');
    } catch (err) {
      setError(err.response?.data?.error || 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 pt-20">
      <div className="bg-white rounded-lg shadow-2xl p-8 w-full max-w-md">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-2">
          {isSignup ? 'Create Account' : 'Welcome Back'}
        </h2>
        <p className="text-center text-gray-600 mb-8">
          {isSignup ? 'Start your career journey today' : 'Login to your GigYaatra account'}
        </p>

        {error && (
          <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded text-red-700 text-sm">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {isSignup && (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">First Name</label>
                <input
                  type="text"
                  value={formData.firstName}
                  onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">Last Name</label>
                <input
                  type="text"
                  value={formData.lastName}
                  onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500"
                />
              </div>
            </>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-900 mb-2">Email</label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-900 mb-2">Password</label>
            <input
              type="password"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              required
              minLength="6"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-lg font-bold disabled:opacity-50"
          >
            {loading ? 'Loading...' : isSignup ? 'Sign Up' : 'Sign In'}
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-gray-600">
            {isSignup ? 'Already have an account?' : "Don't have an account?"}
            <button
              onClick={() => setIsSignup(!isSignup)}
              className="ml-2 text-cyan-600 hover:text-cyan-700 font-bold"
            >
              {isSignup ? 'Sign In' : 'Sign Up'}
            </button>
          </p>
        </div>

        {!isSignup && (
          <div className="mt-6 p-4 bg-blue-50 rounded border border-blue-200 text-sm text-blue-800">
            <p className="font-bold mb-2">🎯 Demo Account</p>
            <p>Email: demo@gigyaatra.com</p>
            <p>Password: Demo@123</p>
          </div>
        )}
      </div>
    </div>
  );
};

const quizQuestions = [
  {
    key: 'q1_personality',
    question: 'How would you describe your personality?',
    options: ['creative', 'analytical', 'social', 'practical'],
  },
  {
    key: 'q2_workStyle',
    question: "What's your preferred work style?",
    options: ['independent', 'collaborative', 'structured', 'flexible'],
  },
  {
    key: 'q3_creativity',
    question: 'How creative do you consider yourself?',
    options: ['veryCreative', 'creative', 'moderate', 'analytical'],
  },
  {
    key: 'q4_technical',
    question: 'How comfortable are you with technology?',
    options: ['veryComfortable', 'comfortable', 'somewhat', 'notComfortable'],
  },
  {
    key: 'q5_communication',
    question: 'Rate your communication skills:',
    options: ['excellent', 'good', 'moderate', 'prefer_listening'],
  },
  {
    key: 'q6_timeCommitment',
    question: 'How much time can you dedicate?',
    options: ['full_time', 'part_time', 'flexible', 'occasional'],
  },
  {
    key: 'q7_fieldOfInterest',
    question: 'What field interests you most?',
    options: ['technology', 'design', 'business', 'creative', 'media', 'music'],
  },
  {
    key: 'q8_workEnvironment',
    question: 'Preferred work environment:',
    options: ['remote', 'office', 'hybrid', 'flexible'],
  },
  {
    key: 'q9_learningStyle',
    question: 'How do you learn best?',
    options: ['visual', 'hands_on', 'reading', 'discussion'],
  },
  {
    key: 'q10_goals',
    question: "What's your primary goal?",
    options: ['income', 'impact', 'expression', 'creation', 'passion'],
  },
];

const Quiz = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleNext = async () => {
    if (!answers[quizQuestions[currentStep].key]) {
      setError('Please select an answer');
      return;
    }

    if (currentStep < quizQuestions.length - 1) {
      setCurrentStep(currentStep + 1);
      setError('');
    } else {
      setLoading(true);
      try {
        await api.submitQuiz(answers);
        navigate('/dashboard');
      } catch (err) {
        setError('Failed to submit quiz');
      } finally {
        setLoading(false);
      }
    }
  };

  const q = quizQuestions[currentStep];

  return (
    <div className="min-h-screen pt-20 pb-20 px-4">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold text-white mb-2 text-center">Discover Your Interests</h1>

        <div className="bg-white rounded-lg p-8 shadow-lg mt-8">
          <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-cyan-600">
                Step {currentStep + 1} of {quizQuestions.length}
              </span>
              <span className="text-sm text-gray-600">
                {Math.round(((currentStep + 1) / quizQuestions.length) * 100)}%
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-gradient-to-r from-cyan-500 to-blue-500 h-2 rounded-full transition-all"
                style={{ width: `${((currentStep + 1) / quizQuestions.length) * 100}%` }}
              ></div>
            </div>
          </div>

          <h2 className="text-2xl font-bold text-gray-900 mb-6">{q.question}</h2>

          <div className="space-y-3">
            {q.options.map((option) => (
              <button
                key={option}
                onClick={() => setAnswers({ ...answers, [q.key]: option })}
                className={`w-full p-4 rounded-lg border-2 transition text-left font-medium ${
                  answers[q.key] === option
                    ? 'border-cyan-500 bg-cyan-50 text-cyan-900'
                    : 'border-gray-200 bg-white text-gray-900 hover:border-cyan-300'
                }`}
              >
                {option.replace(/_/g, ' ')}
              </button>
            ))}
          </div>

          {error && <div className="mt-4 p-4 bg-red-50 text-red-700 rounded text-center text-sm">{error}</div>}

          <div className="mt-8 flex justify-between gap-4">
            <button
              onClick={() => currentStep > 0 && setCurrentStep(currentStep - 1)}
              disabled={currentStep === 0}
              className="flex-1 py-3 border-2 border-slate-400 text-gray-900 rounded-lg hover:border-cyan-400 transition font-bold disabled:opacity-50"
            >
              ← Previous
            </button>
            <button
              onClick={handleNext}
              disabled={loading}
              className="flex-1 py-3 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-lg font-bold disabled:opacity-50"
            >
              {loading ? 'Submitting...' : currentStep === quizQuestions.length - 1 ? 'Complete Quiz' : 'Next →'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const Dashboard = () => {
  const { user } = useContext(AuthContext);
  const { savedGigs, toggleSavedGig } = useContext(UserContext);
  const [interests, setInterests] = useState([]);
  const [skills, setSkills] = useState({});
  const [gigs, setGigs] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const loadData = async () => {
      try {
        if (user?.completedQuiz) {
          const [interestRes, skillRes, gigRes] = await Promise.all([
            api.getInterestRecommendations().catch(() => ({ data: { interests: [] } })),
            api.getSkillRecommendations().catch(() => ({ data: { recommendedSkills: {} } })),
            api.getGigRecommendations().catch(() => ({ data: { gigs: [] } })),
          ]);

          setInterests(interestRes.data.interests || []);
          setSkills(skillRes.data.recommendedSkills || {});
          setGigs(gigRes.data.gigs || []);
        }
      } catch (err) {
        console.error('Error loading dashboard', err);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [user]);

  if (loading) return <LoadingSpinner />;

  return (
    <div className="min-h-screen pt-20 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-slate-800 to-slate-900 rounded-lg p-8 mb-8 border border-slate-700">
          <h1 className="text-3xl font-bold text-white mb-2">Welcome back, {user?.firstName}! 👋</h1>
          {!user?.completedQuiz && (
            <button
              onClick={() => navigate('/quiz')}
              className="mt-4 px-6 py-2 bg-cyan-500 text-white rounded-lg hover:bg-cyan-600 transition font-bold"
            >
              Take Quiz Now
            </button>
          )}
        </div>

        {user?.completedQuiz && interests.length > 0 && (
          <>
            <div className="mb-12">
              <h2 className="text-2xl font-bold text-white mb-6">Your Predicted Interests</h2>
              <div className="grid md:grid-cols-3 gap-6">
                {interests.map((interest, i) => (
                  <div key={i} className="bg-white rounded-lg p-6 border-2 border-slate-200">
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{interest}</h3>
                    <p className="text-sm text-gray-600 mb-4">Strong match for you!</p>
                    <button
                      onClick={() => navigate('/gigs')}
                      className="text-cyan-600 hover:text-cyan-700 font-medium text-sm"
                    >
                      Browse Gigs →
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="mb-12">
              <h2 className="text-2xl font-bold text-white mb-6">Recommended Skills to Learn</h2>
              <div className="grid md:grid-cols-3 gap-6">
                {interests.map((interest) => (
                  <SkillCard key={interest} interest={interest} skills={skills[interest]} />
                ))}
              </div>
            </div>

            <div className="mb-12">
              <h2 className="text-2xl font-bold text-white mb-6">Personalized Gigs for You</h2>
              <div className="grid md:grid-cols-3 gap-6">
                {gigs.slice(0, 6).map((gig) => (
                  <GigCard
                    key={gig._id}
                    gig={gig}
                    isSaved={savedGigs.includes(gig._id)}
                    onSaveToggle={toggleSavedGig}
                  />
                ))}
              </div>
              <div className="text-center mt-8">
                <button
                  onClick={() => navigate('/gigs')}
                  className="px-8 py-3 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-lg font-bold"
                >
                  Browse All Gigs
                </button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

const Gigs = () => {
  const { savedGigs, setSavedGigs, toggleSavedGig } = useContext(UserContext);
  const [gigs, setGigs] = useState([]);
  const [filteredGigs, setFilteredGigs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [difficulty, setDifficulty] = useState('');

  useEffect(() => {
    const loadGigs = async () => {
      try {
        const [gigsRes, savedRes] = await Promise.all([
          api.getAllGigs({}),
          api.getSavedGigs().catch(() => ({ data: { gigs: [] } })),
        ]);

        setGigs(gigsRes.data.gigs);
        setSavedGigs(savedRes.data.gigs.map((g) => g._id));
      } catch (err) {
        console.error('Error loading gigs', err);
      } finally {
        setLoading(false);
      }
    };

    loadGigs();
  }, []);

  useEffect(() => {
    let filtered = gigs;

    if (search) {
      filtered = filtered.filter(
        (g) =>
          g.title.toLowerCase().includes(search.toLowerCase()) ||
          g.description.toLowerCase().includes(search.toLowerCase())
      );
    }

    if (category) filtered = filtered.filter((g) => g.category === category);
    if (difficulty) filtered = filtered.filter((g) => g.difficulty === difficulty);

    setFilteredGigs(filtered);
  }, [gigs, search, category, difficulty]);

  if (loading) return <LoadingSpinner />;

  return (
    <div className="min-h-screen pt-20 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-white mb-8">Browse Gigs</h1>

        <div className="bg-white rounded-lg p-6 mb-8 border-2 border-slate-200">
          <div className="grid md:grid-cols-3 gap-4">
            <input
              type="text"
              placeholder="Search gigs..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500"
            />

            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg bg-white"
            >
              <option value="">All Categories</option>
              {['Development', 'Design', 'Writing', 'Marketing', 'Data', 'Video', 'Music'].map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>

            <select
              value={difficulty}
              onChange={(e) => setDifficulty(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg bg-white"
            >
              <option value="">All Levels</option>
              {['Beginner', 'Intermediate', 'Expert'].map((level) => (
                <option key={level} value={level}>
                  {level}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <p className="text-slate-300 mb-6">Found {filteredGigs.length} gigs</p>

          {filteredGigs.length > 0 ? (
            <div className="grid md:grid-cols-3 gap-6">
              {filteredGigs.map((gig) => (
                <GigCard
                  key={gig._id}
                  gig={gig}
                  isSaved={savedGigs.includes(gig._id)}
                  onSaveToggle={toggleSavedGig}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-white rounded-lg">
              <p className="text-gray-600 text-lg">No gigs found</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const Profile = () => {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [formData, setFormData] = useState({});
  const [newSkill, setNewSkill] = useState('');

  useEffect(() => {
    const loadProfile = async () => {
      try {
        const res = await api.getProfile();
        setProfile(res.data.user);
        setFormData(res.data.user);
      } catch (err) {
        console.error('Error loading profile', err);
      } finally {
        setLoading(false);
      }
    };

    loadProfile();
  }, []);

  const handleAddSkill = async () => {
    if (!newSkill.trim()) return;

    try {
      const res = await api.addSkill(newSkill);
      setProfile((prev) => ({
        ...prev,
        skills: res.data.skills,
      }));
      setNewSkill('');
    } catch (err) {
      console.error('Error adding skill', err);
    }
  };

  const handleRemoveSkill = async (skill) => {
    try {
      const res = await api.removeSkill(skill);
      setProfile((prev) => ({
        ...prev,
        skills: res.data.skills,
      }));
    } catch (err) {
      console.error('Error removing skill', err);
    }
  };

  const handleSaveProfile = async () => {
    try {
      await api.updateProfile(formData);
      setProfile(formData);
      setEditing(false);
    } catch (err) {
      console.error('Error updating profile', err);
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div className="min-h-screen pt-20 pb-20 px-4">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold text-white mb-8">My Profile</h1>

        <div className="bg-white rounded-lg p-8 mb-8 border-2 border-slate-200">
          <div className="flex items-start justify-between mb-6">
            <div className="flex items-center gap-4">
              <img src={profile?.avatar} alt="Avatar" className="w-20 h-20 rounded-full" />
              <div>
                <h2 className="text-2xl font-bold text-gray-900">
                  {formData.firstName} {formData.lastName}
                </h2>
                <p className="text-gray-600">{profile?.email}</p>
              </div>
            </div>
            <button
              onClick={() => setEditing(!editing)}
              className="px-4 py-2 bg-cyan-500 text-white rounded-lg hover:bg-cyan-600 transition"
            >
              {editing ? 'Cancel' : 'Edit'}
            </button>
          </div>

          {editing ? (
            <div className="space-y-4">
              <input
                type="text"
                value={formData.firstName || ''}
                onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                placeholder="First Name"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
              />
              <input
                type="text"
                value={formData.lastName || ''}
                onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                placeholder="Last Name"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
              />
              <textarea
                value={formData.bio || ''}
                onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                placeholder="Bio"
                rows="4"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
              />
              <button
                onClick={handleSaveProfile}
                className="w-full py-3 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-lg font-bold"
              >
                Save Changes
              </button>
            </div>
          ) : (
            <div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">About</h3>
              <p className="text-gray-700">{formData.bio || 'No bio added yet'}</p>
            </div>
          )}
        </div>

        <div className="bg-white rounded-lg p-8 border-2 border-slate-200">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Skills</h3>

          <div className="flex gap-2 mb-6">
            <input
              type="text"
              value={newSkill}
              onChange={(e) => setNewSkill(e.target.value)}
              placeholder="Add a new skill..."
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg"
              onKeyPress={(e) => e.key === 'Enter' && handleAddSkill()}
            />
            <button
              onClick={handleAddSkill}
              className="px-4 py-2 bg-cyan-500 text-white rounded-lg hover:bg-cyan-600 transition font-bold"
            >
              Add
            </button>
          </div>

          <div className="flex flex-wrap gap-2">
            {profile?.skills && profile.skills.length > 0 ? (
              profile.skills.map((skill, i) => (
                <div key={i} className="px-4 py-2 bg-gray-100 border border-gray-300 rounded-full flex items-center gap-2">
                  <span className="font-medium text-gray-900">{skill}</span>
                  <button
                    onClick={() => handleRemoveSkill(skill)}
                    className="text-gray-500 hover:text-red-500 font-bold"
                  >
                    ×
                  </button>
                </div>
              ))
            ) : (
              <p className="text-gray-600">No skills added yet</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// ============ MAIN APP ============

function AppContent() {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
        <Navbar />
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/auth" element={<Auth />} />
          <Route
            path="/quiz"
            element={
              <ProtectedRoute>
                <Quiz />
              </ProtectedRoute>
            }
          />
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <Dashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/gigs"
            element={
              <ProtectedRoute>
                <Gigs />
              </ProtectedRoute>
            }
          />
          <Route
            path="/profile"
            element={
              <ProtectedRoute>
                <Profile />
              </ProtectedRoute>
            }
          />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </Router>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <UserProvider>
        <AppContent />
      </UserProvider>
    </AuthProvider>
  );
}
